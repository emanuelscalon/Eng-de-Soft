  //modulos
var http = require('http');
var qs = require('querystring');

// definicoes
var pageHTML = '<html>' +
'<header>' +
 '  <img alt="logo" src="http://worldartsme.com/images/rectangle-cartoon-face-clipart-1.jpg">' +
  ' <h1>Formulario de Calculo de area do retangulo</h1>' +
 '  </form>' +
'</header>' +
'</head>' +
'<body>' +
'<body background="">' +
'<form method="post" action="">' +
'<div>'+
'<label for="x">Formulario de calculo de area de um retangulo</label>' +
'<div>' +
'<label for="form.Base.value">Base:</label>' +
'<input type="number" class="data_value/><p/>' +
'<div>' +
'<label for="form.Altura.value">Altura:</label>' +
'<input type="number" class="data_value" /><p/>' +
'<input type="button" value="Calcular" onClick="calcula(this.form)" />' +
'<input type="reset" value="Limpar" /><p/>' +
'<tr>' +
'<td>' + 
'<label for="Insira a data da execucao:">Insira a data da execucao:</label>' +
'</td>'+
'<input type="text" name="dia" size="2" maxlength="2" value="dd">' +
'<input type="text" name="mes" size="2" maxlength="2" value="mm"> ' +
'<input type="text" name="ano" size="4" maxlength="4" value="aaaa">' +
'<input type="submit" value="Ok">' +
'</td>' +
'</tr>' +
'<script language="JavaScript">' +
'</script>' +
'<body>' +
'<form >' +
'<div>'+
'<label for="area: ">Result is:</label>' +
'<input type="text" class="data_value" name="resultado" />' +
'</form>' +
'</body>' +
'</html>';
// server e acao apos clique de botao

var server = http.createServer(function (req, res) {
      res.writeHead(200, {'Content-Type': 'text/html'});
  var requestData = '';
 
  // check HTTP method and show the right content
  if (req.method === "GET") {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(pageHTML); // serve our HTML code
  } else if (req.method === "POST") {
    req.setEncoding('utf-8');
/*
    req.on('data', function(data) {
      requestData += data;
    });
*/ 
   req.on('end', function() {
      var postData = qs.parse(requestData);
  res.writeHead(200, {'Content-Type': 'text/html'});

      res.end('<h1>User creation was been success!!!' + '</h1>');
    });
  }
});

/*funcao
function calcula(form) {
var area = (form.Base.value * form.Altura.value);
form.resultado.value = area;
}
*/

 // habilitando listener
server.listen(1310, '127.0.0.1');
console.log('Server running at http://127.0.0.1:1310/');	
