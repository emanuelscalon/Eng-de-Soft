#!/bin/bash
node CalculoCirculoF.js CalculoRetangulo.js CalculoTriangulo.js MenuUsuario.js TelaCriacaoUser.js TelaInicial.js 


echo "Aplication Started"
