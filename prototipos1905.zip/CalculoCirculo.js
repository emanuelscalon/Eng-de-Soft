  //modulos
var http = require('http');
var qs = require('querystring');

// definicoes
var pageHTML = '<html>' +
'<header>' +
 '  <img alt="logo" src="http://4.bp.blogspot.com/-C4bMfjogCFE/T-nUXKO49rI/AAAAAAAAJbY/9sTPFRBPsJM/s1600/penalti16+formula-superficie3.gif">' +
  ' <h1>Calculo de area do Circulo</h1>' +
 '  </form>' +
'</header>' +
'</head>' +
'<body>' +
'<body background="">' +
'<form method="post" action="">' +
'<div>'+
'<div>' +
'<label for="x">Valor Universal de PI: 3.14159265 </label> <p/>' +
'<div>' +
'<label for="Raio">Raio: </label>' +
'<input type="number" class="data_value" /><p/>' +
'<input type="button" value="Calcular" onClick="Area(Area)" />' +
'<input type="reset" value="Limpar" /><p/>' +
'<tr>' +
'<td>' + 
'<label for="Insira a data da execucao:">Insira a data da execucao:</label>' +
'</td>'+
'<input type="text" name="dia" size="2" maxlength="2" value="dd">' +
'<input type="text" name="mes" size="2" maxlength="2" value="mm"> ' +
'<input type="text" name="ano" size="4" maxlength="4" value="aaaa">' +
'</td>' +
'</tr>' +
'<script language="JavaScript">' +
'</script>' +
'<body>' +
'<form >' +
'<div>'+
'<label for="area: ">Result is:</label>' +
'<input type="text" class="data_value" name="resultado" /><p/>' +
'<div>'+
'<input type="button" value="Guardar Dados" onClick="" /><p/>' +
'<div>'+
'</form>' +
'</body>' +
'</html>';
// server e acao apos clique de botao

var server = http.createServer(function (req, res) {
      res.writeHead(200, {'Content-Type': 'text/html'});
  var requestData = '';
 
  // check HTTP method and show the right content
  if (req.method === "GET") {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(pageHTML); // serve our HTML code
  } else if (req.method === "POST") {
    req.setEncoding('utf-8');
/*
    req.on('data', function(data) {
      requestData += data;
    });
*/ 
   req.on('end', function() {
      var postData = qs.parse(requestData);
  res.writeHead(200, {'Content-Type': 'text/html'});

      res.end('<h1>User creation was been success!!!' + '</h1>');
    });
  }
});

function Area()
        {
     var area, Rain, Pi = 3.1416;
            Rain = prompt("Insert a value for Rain");
            

            Rain = parseInt(Rain);
            area = (Pi * (Rain * Rain));

            alert("area:" +area);
        }

 // habilitando listener
server.listen(1300, '127.0.0.1');
console.log('Server running at http://127.0.0.1:1300/');
