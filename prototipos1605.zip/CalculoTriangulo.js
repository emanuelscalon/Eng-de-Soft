 //modulos
var http = require('http');
var qs = require('querystring');

var pageHTML = '<html>' +
'<head>' + '<title> *** Calculate area of Triangle </title>' + '</head>'
'<center>' + '<h1> Calculate area of Triangle' + '</h1>'
'<body bgcolor="red">' +
'<script language="javascript">' +

function Area()
        {
     var area, base, altura;
            base = prompt("Insert a value for base");
            altura = prompt("Insert a value for altura");

            base = parseInt(base);
            altura = parseInt(altura);
            area = (base * altura)/2;

            alert("area:" +area);
        }
    '</script>' +
  '<form name="form1">' +
  '<input type="button" value="calcular" onclick=Area()>' +
   '</form>' +
   '</center>' +
  '</body>' +
'</html>';

var server = http.createServer(function (req, res) {
      res.writeHead(200, {'Content-Type': 'text/html'});
  var requestData = '';
 
  // check HTTP method and show the right content
  if (req.method === "GET") {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(pageHTML); // serve our HTML code
  } else if (req.method === "POST") {
    req.setEncoding('utf-8');
 
    req.on('data', function(data) {
      requestData += data;
    });
 
    req.on('end', function() {
      var postData = qs.parse(requestData);
  res.writeHead(200, {'Content-Type': 'text/html'});

      res.end('<h1>User creation was been success!!!' + '</h1>');
    });
  }
});

 // habilitando listener
server.listen(1360, '127.0.0.1');
console.log('Server running at http://127.0.0.1:1360/');		
