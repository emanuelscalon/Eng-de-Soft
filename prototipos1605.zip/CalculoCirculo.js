// modulos
var http = require('http');
var qs = require('querystring');

// definicoes 
var pageHTML = '<html>' + 
'<head>' + 
'<title> *** Formulario de calculo de area do triangulo ***</title>' +
'</head>' +
'<title> *** Rectangle Area ***</title>' +
'<script language="JavaScript">' +
function calcula(form) {
var area = (eval(form.base.value*form.altura.value))/2;
form.resultado.value = area;
}
'</script>' +
'<body>' +
'<form>' +

//Base:
'<label for="Base">Base:</label>' +
'<input type="text" name="base" /><p/>' +

//Altura:
'<label for="Altura">Altura:</label>' +
'<input type="text" name="altura" /><p/>' +
'<input type="button" value="Calcular" onClick="calcula(this.form)" />' +
'<input type="reset" value="Limpar" /><p/>' +

//Resultado: 
'<label for="Resultado">Resultado:</label>' +
'<input type="text" name="resultado" />' +
'</form>' +
'</body>' +
'</html>';

// server e acao apos clique de botao

var server = http.createServer(function (req, res) {
      res.writeHead(200, {'Content-Type': 'text/html'});
  var requestData = '';
 
  // check HTTP method and show the right content
  if (req.method === "GET") {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(pageHTML); // serve our HTML code
  } else if (req.method === "POST") {
    req.setEncoding('utf-8');
 
    req.on('data', function(data) {
      requestData += data;
    });
 
    req.on('end', function() {
      var postData = qs.parse(requestData);
  res.writeHead(200, {'Content-Type': 'text/html'});

      res.end('<h1>User creation was been success!!!' + '</h1>');
    });
  }
});

 // habilitando listener
server.listen(1390, '127.0.0.1');
console.log('Server running at http://127.0.0.1:1390/');	

